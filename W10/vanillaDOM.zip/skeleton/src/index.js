import * as warmUp from "./warmup";
import * as clock from "./solution/clock.js";
import * as dogs from "./drop_down.js";

window.htmlGenerator = warmUp.htmlGenerator;
// window.clock = warmup.

