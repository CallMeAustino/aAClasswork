
const partyHeader = document.getElementById('party');

export const htmlGenerator = (string, htmlElement) => {
    const stringHTML = document.createElement("p");
    // var text = document.createTextNode(string);
    // stringHTML.appendChild(text);
    stringHTML.textContent = string
    // if (htmlElement.hasChildNodes) htmlElement.removeChild(htmlElement.firstChild);
    let children = Array.from(htmlElement.children);
    children.forEach(el => {
         htmlElement.removeChild(el)
    })
    htmlElement.appendChild(stringHTML);

    // return partyHeader.appendChild(stringHTML.textContent("this is inside p"));
}; 
// export default htmlGenerator


//The string is converted to a <p> tag and appended to the supplied htmlEle.

htmlGenerator('Party Time.', partyHeader);