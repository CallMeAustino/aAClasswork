
const dogs = {
  "Corgi": "https://www.akc.org/dog-breeds/cardigan-welsh-corgi/",
  "Australian Shepherd": "https://www.akc.org/dog-breeds/australian-shepherd/",
  "Affenpinscher": "https://www.akc.org/dog-breeds/affenpinscher/",
  "American Staffordshire Terrier": "https://www.akc.org/dog-breeds/american-staffordshire-terrier/",
  "Tosa": "https://www.akc.org/dog-breeds/tosa/",
  "Labrador Retriever": "https://www.akc.org/dog-breeds/labrador-retriever/",
  "French Bulldog": "https://www.akc.org/dog-breeds/french-bulldog/" 
};

function dogLinkCreator() {
  const result = [];

  const keys = Object.keys(dogs);
  keys.forEach(dog => {
    let aTag = document.createElement('a');
    aTag.innerHTML = dog;
    aTag.href = dogs[dog];
    let liTag = document.createElement('li');
    liTag.classList.add('dog-link');
    liTag.appendChild(aTag);
    result.push(liTag);
  })
  return result;
}

function attachDogLinks() {
  const ulHTML = Array.from(document.getElementsByClassName('drop-down-dog-list'))[0];
  console.log(ulHTML)
  const dogLinks = dogLinkCreator();
  dogLinks.forEach(dog => {
    ulHTML.appendChild(dog);
  })
}

attachDogLinks();